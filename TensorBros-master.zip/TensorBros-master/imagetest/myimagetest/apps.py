from django.apps import AppConfig


class MyimagetestConfig(AppConfig):
    name = 'myimagetest'
