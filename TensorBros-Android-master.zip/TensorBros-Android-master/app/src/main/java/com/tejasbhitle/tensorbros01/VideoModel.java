package com.tejasbhitle.tensorbros01;

/**
 * Created by tejas on 9/9/17.
 */

public class VideoModel {

    private String name;

    public VideoModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
